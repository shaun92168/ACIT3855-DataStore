import connexion
from connexion import NoContent

from sqlalchemy import create_engine, and_
from sqlalchemy.orm import sessionmaker
from base import Base
from scan_in import ScanIn
from body_info import BodyInfo
import datetime
import dateutil.parser
import yaml


with open('app_conf.yaml', 'r') as f:
    app_config = yaml.safe_load(f.read())


# DB_ENGINE = create_engine('sqlite:///records.sqlite')
DB_ENGINE = create_engine('mysql+pymysql://' + app_config['datastore']['user'] + ':' +
                          app_config['datastore']['password'] + '@' + app_config['datastore']['hostname'] +
                          ':' + str(app_config['datastore']['port']) + '/' + app_config['datastore']['db'])
Base.metadata.bind = DB_ENGINE
DB_SESSION = sessionmaker(bind=DB_ENGINE)


def parse_datetime(datestring):
     return dateutil.parser.parse(datestring)

def add_scan_in(ScanRecord):
    """ receives a scan in record """

    session = DB_SESSION()

    scan = ScanIn(ScanRecord['member_id'],
                  ScanRecord['store_id'],
                  ScanRecord['timestamp'])

    session.add(scan)

    session.commit()
    session.close()

    return NoContent, 201


def get_scan_in(startDate, endDate):
    """ Get scan in records from the data store """

    if startDate != "" and endDate !="":

        start = parse_datetime(startDate)
        end = parse_datetime(endDate)

        results_list = []

        session = DB_SESSION()

        results = []

        results = session.query(ScanIn).filter(and_(ScanIn.date_created >= start, ScanIn.date_created <= end))

        for result in results:
            results_list.append(result.to_dict())
            print(result.to_dict())

        session.close()
        return results_list, 200

    else:
        return NoContent, 400


def add_body_info(BodyInfoUpdate):
    """ Add a body info record to the data store """

    session = DB_SESSION()

    bi = BodyInfo(BodyInfoUpdate['member_id'],
                  BodyInfoUpdate['store_id'],
                  BodyInfoUpdate['timestamp'],
                  BodyInfoUpdate['body_info']['weight'],
                  BodyInfoUpdate['body_info']['body_fat'])

    session.add(bi)

    session.commit()
    session.close()

    return NoContent, 201


def get_body_info(startDate, endDate):
    """ Get body info records from the data store """

    if startDate != "" and endDate != "":

        start = parse_datetime(startDate)
        end = parse_datetime(endDate)

        results_list = []

        session = DB_SESSION()

        results = []

        results = session.query(BodyInfo).filter(and_(BodyInfo.date_created >= start, BodyInfo.date_created <= end))

        for result in results:
            results_list.append(result.to_dict())
            print(result.to_dict())

        session.close()
        return results_list, 200
    else:
        return NoContent, 400

app = connexion.FlaskApp(__name__, specification_dir='')
app.add_api("openapi.yaml")

if __name__ == "__main__":
    app.run(port=8090)